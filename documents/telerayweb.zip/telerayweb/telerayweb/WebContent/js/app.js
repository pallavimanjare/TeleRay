// Instantiate the app, the 'myApp' parameter must 
// match what is in ng-app
var app = angular.module('myApp', ['ui.bootstrap', 'ngRoute', 'ngMaterial', 'ngStorage','summernote']);


app.directive('ngFiles', ['$parse', function ($parse) {

    function fn_link(scope, element, attrs) {
        var onChange = $parse(attrs.ngFiles);
        element.on('change', function (event) {
        	console.log('files as ::' + event.target.files);
        	var files = event.target.files;
            onChange(scope, { $files: event.target.files });
        });
    };

    return {
        link: fn_link
    }
} ])


app.service('APIInterceptor', [
		'$q',
		'$location',
		function($q, $location) {
			return {
				'request' : function(config) {
				
					if ($location.absUrl().indexOf('/login.html') == -1) {
										
						config.headers = config.headers || {};

						if (localStorage.getItem('token')) {
							config.headers.Authorization = 'Bearer '
									+ localStorage.getItem('token');
						}
					}

					return config;
				},
				'responseError' : function(response) {
					if (response.status === 401 || response.status === 403) {
						//$window.location.href = 'login.html';
					}
					return $q.reject(response);
				}
			};
		} ]);

app.config(function($routeProvider, $httpProvider) {

	$httpProvider.interceptors.push('APIInterceptor');

	$routeProvider
	// route for the home page
	.when('/index', {
		templateUrl : 'index.html',
		controller : 'UserController'
	}).when('/login', {
		templateUrl : 'login.html',
		controller : 'UserController'
	}).when('/register', {
		templateUrl : 'register.html',
		controller : 'registerController'
	}).when('/add_edit_center', {
		templateUrl : 'html/add_edit_center.html',
		controller : 'UserController'
	});

});

app.controller('registerController', function($scope, $http,$mdDialog) {
	$scope.message = 'Welcome to register screen from here...';
	console.log('Inside Register Controller ::');

	//user type
	$scope.usertypeData = [ {
		label : 'Client',
		value : 'Client'
	}, {
		label : 'RadioLogist',
		value : 'RadioLogist'
	} ];
	$scope.usertype = 'Client';
	//account type
	$scope.accounttypeData = [ {
		label : 'Live',
		value : 'Live'
	}, {
		label : 'Demo',
		value : 'Demo'
	} ];
	$scope.accounttype = 'Demo';
	//MR
	$scope.mrData = [ {
		label : 'High',
		value : 'High'
	}, {
		label : 'Medium',
		value : 'Medium'
	}, {
		label : 'Low',
		value : 'Low'
	} ];
	$scope.mrType = 'High';
	//CT
	//MR
	$scope.ctData = [ {
		label : 'High',
		value : 'High'
	}, {
		label : 'Medium',
		value : 'Medium'
	}, {
		label : 'Low',
		value : 'Low'
	} ];
	$scope.ctType = 'High';


	$scope.countries = [ {
		name : 'India',
		value : 'India'
	}, {
		name : 'USA',
		value : 'USA'
	}, {
		name : 'London',
		value : 'London'
	}, {
		name : 'Shrilanka',
		value : 'Shrilanka'
	}, {
		name : 'aaa',
		value : 'aaa'
	}, {
		name : 'bbb',
		value : 'bbb'
	}, {
		name : 'ccc',
		value : 'ccc'
	}, {
		name : 'ddd',
		value : 'ddd'
	} ];

	$scope.data = {
		selectedIndex : 0
	};

	$scope.next = function() {
		$scope.data.selectedIndex = Math.min($scope.data.selectedIndex + 1, 2);
	};

	$scope.previous = function() {
		$scope.data.selectedIndex = Math.max($scope.data.selectedIndex - 1, 0);
	};

	$scope.project = {
		comments : 'Comments',
	};

  
	  var showAlert = function(message) {
          $mdDialog.show(
             $mdDialog.alert()
                .parent(angular.element(document.querySelector('#dialogContainer')))
                .clickOutsideToClose(false)
                .title('TeleRay Alert')
                .textContent(message)
                .ariaLabel('Alert')
                .ok('Ok!')
                
          );
       };
       
       var handleResponse = function( response, isDisable , isAlert) {
    		console.log('getting response as ::' + response);
    		var statuscode = response.data.header.statuscode;
    		var statusmessage = response.data.header.statusmessage;
    		
    		if(statuscode!= 200 && statusmessage === "failure"){
    			
    			$scope.errormessage = response.data.data.errormessage;
    			$scope.disableButton = true;
    		}else if(statuscode == 200 && statusmessage === "success"){
    			
    			$scope.errormessage = '';
    			if(isDisable){
    			$scope.disableButton = false;
    			}
    			if(isAlert) {
    				showAlert('Congratulations...You have successfully registered with system...Please check with your mails..');
    				$window.location.href = '/login.html';
    			}
    		}  
       };
       
	$scope.formData = {};
	$scope.disableButton = false;
	$scope.checkIsUsernameExist = function() {
	console.log('Inside checkIsUsernameExist');
	var data = {
			"username" : $scope.formData.username
	};
	var configData = localStorage.getItem('configData');	
	
	var configUrl =  JSON.parse(configData);	
	console.log('config url in add user ::' + configUrl);
	
	$scope.hostUrl = configUrl.baseurl+configUrl.checkIsUsernameExist;	
	console.log('checkIsUsernameExist url as' +$scope.hostUrl  );
	$http({
		method : 'POST',
		url : $scope.hostUrl,
		data : data
	}).then(function(response) {			
		handleResponse(response ,true , false);
		
	});
	};
	
	$scope.checkIsEmailAddressExist = function() {
		console.log('Inside checkIsEmailAddressExist');
		var data = {
				"emailaddress" : $scope.formData.emailaddress
		};
		var configData = localStorage.getItem('configData');	
		
		var configUrl =  JSON.parse(configData);	
		console.log('config url in checkIsEmailAddressExist user ::' + configUrl);
		
		$scope.hostUrl = configUrl.baseurl+configUrl.checkIsEmailAddressExist;	
		console.log('checkIsEmailAddressExist url as' +$scope.hostUrl  );
		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : data
		}).then(function(response) {			
		
			handleResponse(response,true , false);
		});
		};
		
	$scope.saveUserInfo = function() {
		console.log('Inside save USer Info');
		var data = {
			"fullname" : $scope.formData.fullname,
			"qualification" : $scope.formData.qualification,
			"profileinfo" : $scope.formData.profileinfo,
			"issms" : $scope.formData.issms,
			"isemail" : $scope.formData.isemail,
			"usertype" : $scope.formData.usertype,
			"accounttype" : $scope.formData.accounttype,
			"MR" : $scope.formData.mrtype,
			"CT" : $scope.formData.cttype,
			"emailaddress" : $scope.formData.emailaddress,
			"mobilenumber" : $scope.formData.mobilenumber,
			"faxnumber" : $scope.formData.faxnumber,
			"hospitalname" : $scope.formData.hospitalname,
			"address" : $scope.formData.address,
			"city" : $scope.formData.city,
			"pincode" : $scope.formData.pincode,
			"country" : $scope.formData.country,
			"username" : $scope.formData.username,
			"password" : $scope.formData.password

		};
		var configData = localStorage.getItem('configData');	
		
		var configUrl =  JSON.parse(configData);	
		console.log('config url in add user ::' + configUrl);
		
		$scope.hostUrl = configUrl.baseurl+configUrl.addUser;
		//$scope.hostUrl = 'http://localhost:3005/users/adduser';
		console.log('add user url as ::' +$scope.hostUrl  );
		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : data
		}).then(function(response) {
			handleResponse(response,false,true);
			
		});
	};

});

app.controller('UserController', function($scope, $location, $http, $window,
		$mdSidenav , $mdDialog ) {
console.log('Inside User Controller');
//bootbox.alert("Hello world!", function() {
//    console.log("Alert Callback");
//});text

	$scope.formData = {};
	$scope.pagetitle = 'TeleRay DashBoard';
	$scope.IsDashboard = true;
	 
	$scope.totalNumbers = [
	                   	{name : '5'}	,
	                   	{name : '10'},
	                   	{name : '15'},
	                   	{name : '20'}];
	 $scope.sortType     = 'name'; // set the default sort type
	  $scope.sortReverse  = false; 

	$scope.message = 'dfjdhfjdfhfjhd!';
	$scope.displayVal = '';
	$scope.IsAddCenter = false;
	$scope.IsEditCenter = false;
	$scope.IsSearchCenter = false;
	
	
	$scope.IsSearchPatientStudies = false;
	$scope.IsEditPatient = false;
	$scope.isUploadPatientStudyInfo = false;
	
	$scope.IsAddStudy = false;
	$scope.IsEditStudy = false;
	$scope.IsSearchStudy = false;
	
	$scope.IsAddStudyReport = false;
	$scope.IsEditStudyReport = false;
	$scope.IsSearchStudyReport = false;
	
	
	$scope.IsAddTemplate = false;
	$scope.IsEditTemplate = false;
	$scope.IsSearchTemplate = false;
	
	$scope.IsAddModality = false;
	
	$scope.IsEditModality = false;
	$scope.IsSearchModality = false;
	
	
	$scope.IsAddKeyword = false;
	$scope.IsEditKeyword = false;
	$scope.IsSearchKeyword = false;
	
	
	$scope.patientCondition = [{name : 'Normal'},
	                           {name : 'Abnormal'}];
	
	$scope.reportType = [ 
	   	            	{name : 'New'},
	   	            	{name : 'Read'},
	   	            	{name : 'Finalize'}
	   	            	];
	$scope.signatureType = [ 
		   	            	{name : 'Text'},
		   	            	{name : 'Image'}
		   	            	];
	$scope.ageType = [
	                  {name : 'Years'},
		   	            	{name : 'Months'}
		   	            	];
	$scope.reportStatus = [ 
	            	{name : 'New'},
	            	{name : 'Read'},
	            	{name : 'Finalize'}
	            	];
	 $scope.radioGender = [
	                     { label: 'Male', value: true },
	                     { label: 'Female', value: false }
	                  ];
	 $scope.gender = 'Male';
	$scope.studyStatus = [ 
	{name : 'New'},
	{name : 'Read'},
	{name : 'Finalize'}
	];
	//	$scope.token = '';

	 var openDialog = function(message){
		    $mdDialog.show({
                clickOutsideToClose: true,
                scope: $scope,        
                preserveScope: true,           
                template: '<md-dialog style="height:250px;width:250px;">' +
                            '  <md-dialog-content><div style="text-align:center;vertical-align:middle">' +message+                            
                            ' </div> </md-dialog-content>' +
                            '</md-dialog>',
                controller: function UserController($scope, $mdDialog) {
                   $scope.closeDialog = function() {
                      $mdDialog.hide();
                   }
                }
             });
		  };
		
		  var showAlert = function(message) {
              $mdDialog.show(
                 $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#dialogContainer')))
                    .clickOutsideToClose(false)
                    .title('TeleRay Alert')
                    .textContent(message)
                    .ariaLabel('Alert')
                    .ok('Ok!')
                    
              );
           };
        	
           var handleResponse = function( response) {
       		console.log('getting response as ::' +JSON.stringify(response));
       		var statuscode = response.data.header.statuscode;
       		var statusmessage = response.data.header.statusmessage;
       		
       		if(statuscode!= 200 && statusmessage === "failure"){
       			
       			$scope.errormessage = response.data.data.errormessage;
       			return false;
       			
       		}else if(statuscode == 200 && statusmessage === "success"){
       			
       			$scope.errormessage = '';
       			return true;
       			
       		}  
          };
          
          
           $scope.ShowContextMenu = function(){
        	    alert('hello');
        	  };
        	  $scope.edit = function() {
        	    $scope.clicked = 'edit was clicked';
        	    console.log($scope.clicked);
        	  };
        	  
	$scope.openLeftMenu = function() {		
		$mdSidenav('left').toggle();
	};
	angular.element(document).ready(function () {
		console.log('openleft menu');
	    $scope.openLeftMenu();
	});

	var getResponse = function(){
		
	}

	//load json file
	$http.get('/config/config.json').success(function(data) {
		localStorage.setItem('configData',JSON.stringify(data));
				

	});
	$scope.useridForChangePassword = '';
	$scope.changepasswordinit = function() {
		console.log('Inside changepasswordinit' +$location.absUrl());
		if($location.absUrl().indexOf('?userid=') !==-1) {
			var data = $location.absUrl().split('=');
			console.log('data as ::' + data[0]+'user id :: '+data[1]);
			$scope.useridForChangePassword = data[1];
			
			
		}
	}
	
	$scope.changePassword = function() {
		console.log('Inside change password');
		//pass user info to change password
		var data = {
				"_id" : $scope.useridForChangePassword,
				"password" : $scope.formData.password,
			};
		var configData = localStorage.getItem('configData');
		var configUrl =  JSON.parse(configData);
		$scope.hostUrl = configUrl.baseurl+configUrl.changePassword;
		console.log("url as "+$scope.hostUrl+"password enterd as ::" + $scope.formData.password + " for user as ::" +$scope.useridForChangePassword );
		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : data

		}).then(function(response) {
		
			console.log('response as ::' + JSON.stringify(response));
			
			var statuscode = response.data.header.statuscode;
			var statusmessage = response.data.header.statusmessage;
			
			if(statuscode!= 200 && statusmessage === "failure"){
				
				$scope.errormessage = response.data.data.errormessage;
			}else if(statuscode == 200 && statusmessage === "success"){
				console.log('Inside Loop');
				$scope.token = JSON.stringify(response.data.data.token);
				$scope.user = JSON.stringify(response.data.data.user);
				localStorage.setItem('token', $scope.token);
				showAlert('Your password Reset Successfully');
				
			}			
		});
	};
	
	$scope.indexInit = function() {
		//todo check whether it comes from verify user or login user
		console.log('init in index function'+$location.absUrl());
		if ($location.absUrl().indexOf('?userid=') !== -1){
			console.log('comes from verify user');
		var data = $location.absUrl().split('=');
		console.log('data as ::' + data[0]+'user id :: '+data[1]);
		var configData = localStorage.getItem('configData');
		var configUrl =  JSON.parse(configData);		
		$scope.hostUrl = configUrl.baseurl+configUrl.getUserInfoFromId;
		var userid = data[1];
		console.log('user id as ::' + userid);
		var user_data = {
				"_id" : userid
			};

		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : user_data

		}).then(function(response) {
		
			console.log('response as ::' + JSON.stringify(response));
			
			var statuscode = response.data.header.statuscode;
			var statusmessage = response.data.header.statusmessage;
			
			if(statuscode!= 200 && statusmessage === "failure"){
				
				$scope.errormessage = response.data.data.errormessage;
			}else if(statuscode == 200 && statusmessage === "success"){
				console.log('Inside Loop');
				$scope.token = JSON.stringify(response.data.data.token);
				$scope.user = JSON.stringify(response.data.data.user);
				localStorage.setItem('token', $scope.token);
				
			}			
		});

		
		
		
		//get information for user
		} else {
			console.log('comes from login user');
		}
		
		
		
	};
	$scope.addUser = function()	{
		console.log('Inside add user');
		$window.location.href = 'html/register.html';
	};
	$scope.forgotPassword = function()	{
		console.log('Inside add user');
		$window.location.href = 'html/forgot_password.html';
	};
	$scope.logout = function() {
		localStorage.clear();
		$window.location.href = '/login.html';
		
	}
	$scope.adddigitalsignature = function() {
	$scope.formData = {};
	$scope.IstextSignature = false;
	$scope.IsimageSignature = false;
		
		displayVal = 'IsAddDigitalSignature';
		setFlagStatus(displayVal);		
				
		$scope.pagetitle = 'Add Digital Signature';

	};
	$scope.sendLinkForForgotPassword = function() {
		console.log('Inside sendLinkForForgotPassword' + $scope.formData.emailaddress);		
		//sendEmailForForgotPassword
		var emailaddress = $scope.formData.emailaddress;
		var configData = localStorage.getItem('configData');
		var configUrl =  JSON.parse(configData);		
		$scope.hostUrl = configUrl.baseurl+configUrl.sendEmailForForgotPassword;
		var user_data = {
				"emailaddress" : emailaddress
			};
		console.log('URL :::' + $scope.hostUrl);
		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : user_data

		}).then(function(response) {
			showAlert('Please check your mail.updated link has been sent...');
		})
	};
	

	
	$scope.authRequest = function() {
		
		console.log('Inside authRequest');
		$scope.isLoading = true;
		$scope.errormessage = '';
		var user_data = {
			"username" : $scope.formData.username,
			"password" : $scope.formData.password,
		};

		//get config url
		var configData = localStorage.getItem('configData');
		var configUrl =  JSON.parse(configData);		
		$scope.hostUrl = configUrl.baseurl+configUrl.authUser;
		

		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : user_data

		}).then(function(response) {
		
			console.log('response as ::' + JSON.stringify(response));
			var getResponse =  handleResponse(response);
			
			if(getResponse){
				$scope.token = JSON.stringify(response.data.data.token);
				$scope.user = JSON.stringify(response.data.data.user);
				localStorage.setItem('token', $scope.token);
				console.log('getting user id in auth request');
				localStorage.setItem('user', $scope.user);
				openDialog('Login Successfully');
				//$scope.isLoading = false;
				$window.location.href = 'html/index.html';
			}
						
		});

	};
	//center related functions:::

	  

	var setFlagStatus = function(flagname){
		$scope.IsDashboard = false;
		$scope.IsSearchCenter = false;
		$scope.IsAddCenter = false;
		$scope.IsSearchPatientStudies = false;
		$scope.isUploadPatientStudyInfo = false;
		$scope.IsEditPatient = false;
		
		$scope.IsAddStudy = false;
		$scope.IsEditStudy = false;
		$scope.IsSearchStudy = false;
		
		$scope.IsAddStudyReport = false;
		$scope.IsEditStudyReport = false;
		$scope.IsSearchStudyReport = false;
		
		$scope.IsAddTemplate = false;
		$scope.IsEditTemplate = false;
		$scope.IsSearchTemplate = false;
		
		$scope.IsAddModality = false;
		$scope.IsEditModality = false;
		$scope.IsSearchModality = false;
		
		
		$scope.IsAddKeyword = false;
		$scope.IsEditKeyword = false;
		$scope.IsSearchKeyword = false;
		
		$scope.IsAddDigitalSignature = false;

		if(flagname === 'IsDashboard'){
			$scope.IsDashboard = true;
		} else if(flagname === 'IsAddCenter' ){
			console.log('Inside isaddcenter in setflagstatus');
			$scope.IsAddCenter = true;
		} else if(flagname === 'IsSearchCenter'){
			$scope.IsSearchCenter = true;
		} 
		else if(flagname === 'IsSearchPatientStudies') {
			$scope.IsSearchPatientStudies = true;
		} else if(flagname === 'isUploadPatientStudyInfo'){
			$scope.isUploadPatientStudyInfo = true;
		} else if(flagname === 'IsEditPatient'){
			$scope.IsEditPatient = true;
		} else if(flagname === 'IsAddStudy'){
			$scope.IsAddStudy = true;
		} else if(flagname === 'IsEditStudy'){
			$scope.IsEditStudy = true;
		} else if(flagname === 'IsSearchStudy'){
			$scope.IsSearchStudy = true;
		} else if(flagname === 'IsAddStudyReport'){
			$scope.IsAddStudyReport = true;
		} else if(flagname === 'IsEditStudyReport'){
			$scope.IsEditStudyReport = true;
		} else if(flagname === 'IsSearchStudyReport'){
			$scope.IsSearchStudyReport = true;
		} else if(flagname === 'IsAddTemplate'){
			$scope.IsAddTemplate = true;
		} else if(flagname === 'IsEditTemplate'){
			$scope.IsEditTemplate = true;
		} else if(flagname === 'IsSearchTemplate'){
			$scope.IsSearchTemplate = true;
		} else if(flagname === 'IsAddModality'){
			$scope.IsAddModality = true;
		} else if(flagname == 'IsEditModality'){
			$scope.IsEditModality = true;
		} else if(flagname === 'IsSearchModality'){
			$scope.IsSearchModality = true;
		} else if(flagname === 'IsAddKeyword'){
			$scope.IsAddKeyword = true;
		} else if(flagname === 'IsEditKeyword'){
			$scope.IsEditKeyword = true;
		} else if(flagname === 'IsSearchKeyword'){
			$scope.IsSearchKeyword = true;
		}else if(flagname === 'IsAddDigitalSignature'){
			$scope.IsAddDigitalSignature = true;
		}
	}
	$scope.signatureChanged = function(){		
	 var selectedType = $scope.formData.signatureType;
	 if(selectedType === 'Text'){
		 $scope.IstextSignature = true;
		 $scope.IsimageSignature = false;
			
	 }else if(selectedType == 'Image'){
		 console.log('selected type as ::Image'+$scope.IsimageSignature);
		 $scope.IsimageSignature = true;
		 $scope.IstextSignature = false;
	 }
	};
	
	
	$scope.addCenter = function() {

		$scope.formData = {};
		
		displayVal = 'IsAddCenter';
		setFlagStatus(displayVal);		
				
		$scope.pagetitle = 'Add Center Information';

		//$mdSidenav('left').close();
		console.log('add center::' + $scope.IsAddCenter + 'title of page becomes ::' +$scope.pagetitle );
	};

	$scope.searchCenter = function() {
		
		$scope.pagetitle = 'Search Center Information';
		
		
		$scope.centerResults = [];
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchCenter;
	
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting center information as ::"
							+ JSON.stringify(response));
					
						if(handleResponse(response)) {
							console.log('response as ::' + JSON.stringify(response.data.data.centers));
						$scope.centerResults = response.data.data.centers;
						  $scope.totalItems = $scope.centerResults.length;
						  $scope.currentPage = 1;
						  $scope.numPerPage = 5;
//						  http://plnkr.co/edit/79yrgwiwvan3bAG5SnKx?p=preview
						  $scope.paginate = function(value) {
							  console.log('Inside paginate center');
							    var begin, end, index;
							    begin = ($scope.currentPage - 1) * $scope.numPerPage;
							    end = begin + $scope.numPerPage;
							    index = $scope.centerResults.indexOf(value);
							    return (begin <= index && index < end);
							  };
						
							  displayVal = 'IsSearchCenter';
								setFlagStatus(displayVal);
						}

				});
		

	};
	
	
	
	
	
	$scope.geteditCenterInfo = function(centerID) {		
		
		displayVal = 'IsEditCenter';
		setFlagStatus(displayVal);	
		
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		
		var editUrl = configUrl.getCenterForEdit;;
		
		$scope.hostUrl = configUrl.baseurl+"/centers/" + centerID + "/edit";
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					console.log("getting center information as for edit ::"
							+ JSON.stringify(response));
					var getResponse = handleResponse(response);
					if(getResponse) {
						$scope.formData = response.data.data.center;
						console.log('center data as :' + JSON.stringify($scope.formData));
					
					}
					
				});

	};
	


	$scope.deleteCenterInfo = function(centerID) {
		///:id/edit
		//
	
		console.log('Inside Delete Center');
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		
		var editUrl = configUrl.getCenterForEdit;;
		$scope.hostUrl = "http://localhost:3005/centers/" + centerID
		+ "/deleteCenter";
		
		console.log('Delete center URL as ::' + $scope.hostUrl);
		
		var _id = centerID;
		
		$http({
			method : 'POST',
			url : $scope.hostUrl,			
			headers : {
				'Content-Type' : 'application/json'				
			}
			

		}).then(
				function(response) {
					console.log("getting delete center information ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {					
						$scope.centerResults = [];
						$scope.centerResults = response.data.data.centers;
						console.log('center data as :' + JSON.stringify($scope.centerResults));
					}

					
				});

	};

	
	$scope.addeditCenterInfo = function() {
	
		//	  $scope.token = localStorage.getItem('session-token');
		console.log("token store as::" + $scope.token);
		//add center information
		var center_data = {
			"centername" : $scope.formData.centername,
			"centeraddress" : $scope.formData.centeraddress,
			"centercity" : $scope.formData.centercity,
			"centerpincode" : $scope.formData.centerpincode,
			"centercontactno1" : $scope.formData.centercontactno1,
			"centercontactno2" : $scope.formData.centercontactno2,
			"hospitalname" : $scope.formData.hospitalname,
			"hospitaladdress" : $scope.formData.hospitaladdress

		};

		if ($scope.IsAddCenter === true) {
					
			var configData = localStorage.getItem('configData');		
			var configUrl =  JSON.parse(configData);				
			$scope.hostUrl = configUrl.baseurl+configUrl.addCenter;
			
			
			
			$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : center_data,
				headers : {
					'Content-Type' : 'application/json'				
				}

			}).then(function(response) {
				
				if(handleResponse(response)) {
					
					openDialog("Center added successfully");
					$window.location.href = 'index.html';
					console.log('center added successfully as :' + JSON.stringify(response.data.data.center));
				}
			});

		} else if ($scope.IsEditCenter === true) {
			
			var centerId = $scope.formData._id;
			console.log('center ID for Edit AS;' + centerId);
			$scope.hostUrl = "http://localhost:3005/centers/" + centerId
					+ "/edit";
			$http({
				method : 'PUT',
				url : $scope.hostUrl,
				data : center_data,
				headers : {
					'Content-Type' : 'application/json'
				}

			}).then(
					function(response) {
						console.log("getting center information as for edit ::"
								+ JSON.stringify(response));
						if(handleResponse(response)) {
							$scope.formData = response.data.data.center;
							openDialog("Center edited successfully");
							$window.location.href = 'index.html';
							console.log('center added successfully as :' + JSON.stringify(response.data.data.center));
						}

					});
		}
	};
	
	//
	

	//patient related functions:::
	$scope.searchPatientStudies = function() {
		console.log("inside searchPatient");
		$scope.pagetitle = 'Search Patient  Studies Information';
		$scope.patientstudyResults= [];		
		displayVal = 'IsSearchPatientStudies';
		setFlagStatus(displayVal);
		
		
		
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchPatientStudies;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting patient information as ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.patientstudyResults = response.data.data.patientstudies;					
							  
						  $scope.totalItems = $scope.patientstudyResults.length;
						  $scope.currentPage = 1;
						  $scope.numPerPage = 5;
//						  http://plnkr.co/edit/79yrgwiwvan3bAG5SnKx?p=preview
						  $scope.paginate = function(value) {
							 
							    var begin, end, index;
							    begin = ($scope.currentPage - 1) * $scope.numPerPage;
							    end = begin + $scope.numPerPage;
							    index = $scope.patientstudyResults.indexOf(value);
							    return (begin <= index && index < end);
							  };
						console.log('getting patient details as :: ' + $scope.patientstudyResults);
					
					}

				});

	};
	$scope.geteditPatientInfo = function(patientID) {
		///:id/edit
		displayVal = 'IsEditPatient';
		setFlagStatus(displayVal);
	
		
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		
		var editUrl = configUrl.getCenterForEdit;;
		
		$scope.hostUrl = configUrl.baseurl+"/patients/" + patientID + "/edit";
		console.log('patient Id as ::' + patientID);
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					console.log("getting patient information as for edit ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.formData = response.data.data.patient;
						console.log('patient data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	 $scope.from = new Date();
	    $scope.from.setMonth($scope.from.getMonth()-1);
	    $scope.to = new Date();

$scope.createNewReport = function(result) {
	
	var studystatus = JSON.stringify(result.studystatus);
	console.log('status as ::' + studystatus);
	 studystatus =  studystatus.replace( /"/g, "" );
	 console.log('status as ::' + studystatus);
	if(studystatus == "New")
		{
		$scope.patientStudyRecord = result;
		//send to report link
		
		console.log('New has been set');
		addStudyReport();
		//send to report
		}
	else {
		console.log('No new is there');
	}
}
	$scope.uploadPatientStudyInfo = function() {
		$scope.formData = {};
		displayVal = 'isUploadPatientStudyInfo';
		setFlagStatus(displayVal);	
		
		$scope.pagetitle = 'Add Patient Study Information';
		//$mdSidenav('left').close();
		console.log('add patient::' + $scope.isUploadPatientStudyInfo);
	};
	
	$scope.addPatientStudyImageInfo = function() {
		console.log('Inside addPatientStudyImageInfo');
		
		var user = localStorage.getItem('user');		
		var userfromstorage =  JSON.parse(user);				
		
		var userId = JSON.stringify(userfromstorage._id);
		var patientStudyInfo = {
				"fullname" : $scope.formData.fullname,
				"address" : $scope.formData.address,
				"city" : $scope.formData.city,
				"pincode" : $scope.formData.pincode,
				"age" : $scope.formData.age,
				"agetype" : $scope.formData.ageType,
				"gender" : $scope.formData.gender,
				"dateofbirth" : $scope.formData.dateofbirth,
				"mobilenumber" : $scope.formData.mobilenumber,
				"emailaddress" : $scope.formData.emailaddress,
				"history" : $scope.formData.history ,
				"priliminaryreport" :$scope.formData.priliminaryreport ,
				"comments" :$scope.formData.comments,				
				"studyorgan" : $scope.formData.studyorgan,
				"studystatus" : $scope.formData.studyStatus,
				"referringphysicianname" : $scope.formData.referringphysicianname,
				"referringphysicianhospitalname" : $scope.formData.referringphysicianhospitalname,
				"comments" : $scope.formData.comments,
				"description" : $scope.formData.description,
				"createdby" : userId
			};
	
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.addPatientStudyImageInfo;
		console.log('hitting url as :' + $scope.hostUrl);
		
		$http({
			method : 'POST',
			url : $scope.hostUrl,
			data : patientStudyInfo,
			headers : {
				'Content-Type' : 'application/json'				
			}

		}).then(function(response) {
			if(handleResponse(response)) {
				console.log('patient added successfully as :' + JSON.stringify(response.data.data.patientstudy));
				$scope.studyid = response.data.data.patientstudy._id;
				console.log('getting id s ::' + $scope.studyid);
				showAlert("You study information saved successfully...");
			}
		});
	};
	//edit study
	$scope.addStudy = function() {
		$scope.formData = {};	
		displayVal = 'IsAddStudy';
		setFlagStatus(displayVal);	
		
		$scope.pagetitle = 'Add Study Information';
		//$mdSidenav('left').close();
		console.log('add IsAddStudy::' + $scope.IsAddStudy);
	};
	
	$scope.searchStudy = function() {
		console.log("inside search studyResults");
		$scope.pagetitle = 'Search Study Information';
		$scope.studyResults= [];
		displayVal ='IsSearchStudy';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchStudy;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting study information as ::"
							+ JSON.stringify(response));
					
					if(handleResponse(response)) {
						$scope.studyResults = response.data.data.studies;
						$scope.IsSearchStudy = true;
						console.log('getting study details as :: ' + $scope.studyResults);
						console.log('value for $scope.IsSearchStudy ' +$scope.IsSearchStudy );
					
					}

				});

	};
	
	$scope.geteditStudyInfo = function(studyId) {
		///:id/edit
		//
		console.log('Inside getEditStudyInfo:::' + studyId);	
		displayVal ='IsEditStudy';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);		
		
		$scope.hostUrl = configUrl.baseurl+"/studies/" + studyId + "/edit";
		
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.formData = response.data.data.study;
						
						console.log('study info  data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	
	  var getstudyImages = function() {
	    	 //TODO need to pass study id as parameter
		  $scope.studyImageResult = [];
	    	 console.log('getting study id as ::' +$scope.patientStudyRecord._id );
	    	 
	    	 var configData = localStorage.getItem('configData');
	    	 console.log('configdata as::' +configData );
	 		var configUrl =  JSON.parse(configData);				
	 		$scope.hostUrl = configUrl.baseurl+configUrl.getStudyImages;
	 		console.log('url becomes ::' +$scope.hostUrl);
	 		var data = {
	 				"studyid" : $scope.patientStudyRecord._id
	 		}
	 		
	 		$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : data,
				headers : {
					'Content-Type' : 'application/json'				
				}

	 		}).then(
	 				function(response) {
	 					if(handleResponse(response)) {
	 						$scope.studyImageResult = response.data.data.studyimages;
	 						
	 						console.log('getting studyImageResult details as :: ' +JSON.stringify($scope.studyImageResult));
	 						
	 					
	 					}

	 				});

	    	 
	     };
	
	//study report 
	var addStudyReport = function() {
		$scope.formData = {};
		displayVal = 'IsAddStudyReport';
		setFlagStatus(displayVal);		
		
		$scope.pagetitle = 'Add  Report Information';
		getstudyImages();
		getTemplateData();
		
		
		//$mdSidenav('left').close();
		console.log('add addStudyReport::' + $scope.IsAddStudyReport);
	};
	
	
$scope.addeditStudyReportInfo = function() {
		
		//get patientstudy id
	var user = localStorage.getItem('user');		
	var userfromstorage =  JSON.parse(user);				
	
	var userId = JSON.stringify(userfromstorage._id);
	console.log('Report generated for study ::' +JSON.stringify($scope.patientStudyRecord._id) + 'user id as ::' + userId);
	
	
		var studyreport_data = {
			"studyid" : $scope.patientStudyRecord._id,			
			"physiciancomment" : $scope.formData.physiciancomment,
			"patientcondition" : $scope.formData.patientCondition,
			"reportstatus" : $scope.formData.reportStatus,
			"reporttype" : $scope.formData.reportType,
			"templateid" : $scope.formData.templateResults,
			"reportdescription" : $scope.formData.reportdescription,			
			"createdby" : userId
			};

		//if ($scope.IsAddStudyReport === true) {
					
			var configData = localStorage.getItem('configData');		
			var configUrl =  JSON.parse(configData);				
			$scope.hostUrl = configUrl.baseurl+configUrl.addStudyReport;
			console.log('Url becomes ::' +$scope.hostUrl);
			
			$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : studyreport_data,
				headers : {
					'Content-Type' : 'application/json'				
				}

			}).then(function(response) {
				if(handleResponse(response)) {				
					openDialog("study added successfully");
					$window.location.href = 'index.html';
					console.log('study report added successfully as :' + JSON.stringify(response.data.data.studyreport));
				}
			});
	};
	
	$scope.searchStudyReport = function() {
		console.log("inside search studyResults");
		$scope.pagetitle = 'Search Report Information';
		$scope.studyResults= [];		
		displayVal = 'IsSearchStudyReport';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchStudyReport;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting study report information as ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.studyResults = response.data.data.studyreports;
						$scope.IsSearchStudyReport = true;
						console.log('getting study details as :: ' + $scope.studyResults);
						console.log('value for $scope.IsSearchStudy ' +$scope.IsSearchStudyReport );
					
					}

				});

	};
	
	$scope.geteditStudyReportInfo = function(reportId) {
		///:id/edit
		//
		console.log('Inside getEditStudyInfo:::' + reportId);
		displayVal = 'IsEditStudyReport';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		$scope.hostUrl = configUrl.baseurl+"/studyreports/" + reportId + "/edit";
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					console.log("getting reportId information as for edit ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.formData = response.data.data.studyreport;
						
						console.log('study report info  data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	
	//Template
	$scope.addTemplate = function() {
		$scope.formData = {};
	
		displayVal ='IsAddTemplate';
		setFlagStatus(displayVal);
	
		$scope.pagetitle = 'Add Template Information';
		getTemplateData();
		getModality();
	
		 
	};

	   $scope.getFileDetails = function (e) {

		   console.log('Inside getFileDetails');
           $scope.files = [];
           $scope.$apply(function () {

               // STORE THE FILE OBJECT IN AN ARRAY.
               for (var i = 0; i < e.files.length; i++) {
                   $scope.files.push(e.files[i])
                   console.log('file info as ::' + e.files[i]);
               }

           });
       };
       // NOW UPLOAD THE FILES.
       

           
           var formdata = new FormData();
           
           $scope.getTheFiles = function ($files) {
               angular.forEach($files, function (value, key) {
            	   var files = $files;
            	   console.log('file name as ::' + files[key].name);
            	   console.log('Inside getTheFiles::' + key+'key as ::' + JSON.stringify(value) + 'value as ::');
                 //  formdata.append(key, value);
            	   formdata.append("file",files[key],files[key].name);
               });
           };
           
           $scope.uploadFiles = function () {
   			
   			var configData = localStorage.getItem('configData');		
   			var configUrl =  JSON.parse(configData);
   			formdata.append("studyid" , $scope.studyid);
   			var user = localStorage.getItem('user');		
   			var userfromstorage =  JSON.parse(user);				
   			
   			var userId = JSON.stringify(userfromstorage._id);
   			formdata.append("createdby" , userId);   	
   			console.log('getting user id as ::' + userId);
   			
   			$scope.hostUrl = configUrl.baseurl+configUrl.uploadFiles;
              console.log('URL becomes' +$scope.hostUrl);
                  var request = {
                      method: 'POST',
                      url: $scope.hostUrl,
                      data: formdata,
                      transformRequest: angular.identity,
                      headers: {
                          'Content-Type': undefined
                      }
                  };

                  // SEND THE FILES.
                  $http(request)
                      .success(function (d) {
                    	  showAlert("You study images uploaded successfully...");
                      })
                      .error(function () {
                      });
              };
       
       
       
       // UPDATE PROGRESS BAR.
       function updateProgress(e) {
           if (e.lengthComputable) {
               document.getElementById('pro').setAttribute('value', e.loaded);
               document.getElementById('pro').setAttribute('max', e.total);
           }
       }

       // CONFIRMATION.
       function transferComplete(e) {
           alert("Files uploaded successfully.");
       }
	
$scope.addeditTemplateInfo = function() {
		
		//	  $scope.token = localStorage.getItem('session-token');
		
		//add center information
	console.log('Inside addeditTemplateInfo');
	var user = localStorage.getItem('user');		
	var userfromstorage =  JSON.parse(user);				
	
	var userId = JSON.stringify(userfromstorage._id);
	
		var template_data = {
			"templatename" : $scope.formData.templatename,	
			"modalityid" : $scope.formData.modalityResults,
			"studyorgan" : $scope.formData.studyorgan,
			"createdby" : userId,
			"templatedata" : $scope.formData.templatedata
			};

//		if ($scope.IsAddTemplate === true) {
					
			var configData = localStorage.getItem('configData');		
			var configUrl =  JSON.parse(configData);				
			$scope.hostUrl = configUrl.baseurl+configUrl.addTemplate;
			console.log('Url becomes ::' +$scope.hostUrl);
			
			$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : template_data,
				headers : {
					'Content-Type' : 'application/json'				
				}

			}).then(function(response) {
				
				if(handleResponse(response)) {				
					openDialog("template added successfully");
					$window.location.href = 'index.html';
					console.log('study report added successfully as :' + JSON.stringify(response.data.data.template));
				}
			});

	};
	
	var getTemplateData = function() {
		console.log("inside search getTemplateData");
		$scope.templateResults= [];

		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchTemplate;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting template  information as ::"
							+ JSON.stringify(response));
					
					if(handleResponse(response)) {
						$scope.templateResults = response.data.data.templates;						
						console.log('getting templateResults details as :: ' + $scope.templateResults);
						
					
					}

				});

	};
	
	$scope.searchTemplate = function() {
		console.log("inside search studyResults");
		$scope.templateResults= [];
		displayVal ='IsSearchTemplate';
		setFlagStatus(displayVal);
	
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchTemplate;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.templateResults = response.data.data.templates;
						$scope.IsSearchTemplate = true;
						console.log('getting templateResults details as :: ' + $scope.templateResults);
						console.log('value for $scope.IsSearchTemplate ' +$scope.IsSearchTemplate );
					
					}

				});

	};
	
	$scope.geteditTemplateInfo = function(templateId) {
		///:id/edit
		//
		console.log('Inside gettemplateInfo:::' + templateId);
		displayVal = 'IsEditTemplate';
		setFlagStatus(displayVal);
	
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		
		
		
		$scope.hostUrl = configUrl.baseurl+"/templates/" + templateId + "/edit";
		
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.formData = response.data.data.template;
						
						console.log('template info  data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	
	
	//Modality
	//
	$scope.addModality = function() {
		$scope.formData = {};
	
		displayVal ='IsAddModality';
		setFlagStatus(displayVal);
		
		$scope.pagetitle = 'Add Modality Information';
		//$mdSidenav('left').close();
		console.log('add IsAddTemplate::' + $scope.IsAddModality);
		 $window.open("add_edit_template.html", "popup", "width=300,height=200,left=10,top=150");
	};
	
	
$scope.addeditModalityInfo = function() {
		
		//	  $scope.token = localStorage.getItem('session-token');
		
		//add center information
	console.log('Inside addeditModalityInfo');
		var modality_data = {
			"modalityname" : $scope.formData.modalityname		
			
			};

		if ($scope.IsAddModality === true) {
					
			var configData = localStorage.getItem('configData');		
			var configUrl =  JSON.parse(configData);				
			$scope.hostUrl = configUrl.baseurl+configUrl.addModality;
			console.log('Url becomes ::' +$scope.hostUrl);
			
			$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : modality_data,
				headers : {
					'Content-Type' : 'application/json'				
				}

			}).then(function(response) {
				
				if(handleResponse(response)) {				
					openDialog("template added successfully");
					$window.location.href = 'index.html';
					console.log('study report added successfully as :' + JSON.stringify(response.data.data.modality));
				}
			});

		} else if ($scope.IsEditModality === true) {
			
			var modalityid = $scope.formData._id;
			console.log('study ID for Edit AS;' + modalityid);
			$scope.hostUrl = "http://localhost:3005/modalities/" + modalityid
					+ "/edit";
			$http({
				method : 'PUT',
				url : $scope.hostUrl,
				data : modality_data,
				headers : {
					'Content-Type' : 'application/json'
						}

			}).then(
					function(response) {
						if(handleResponse(response)) {
							$scope.formData = response.data.data.modality;
							openDialog("modality edited successfully");
							$window.location.href = 'index.html';
							console.log('study added successfully as :' + JSON.stringify(response.data.data.modality));
						}

					});
		}
	};
	
	$scope.searchModality = function() {
		console.log("inside search Modality");
		$scope.modalityResults= [];
		
		displayVal ='IsSearchModality';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchModality;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.modalityResults = response.data.data.modalities;
						$scope.IsSearchModality = true;
						console.log('getting modality details as :: ' + $scope.IsSearchModality);
						
					
					}

				});

	};
	
	var getModality  = function() {
		console.log("inside search Modality");
		$scope.modalityResults= [];		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchModality;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.modalityResults = response.data.data.modalities;						
						console.log('getting modality details as :: ' + $scope.modalityResults);
						
					
					}
				});

	};
	
	$scope.geteditModalityInfo = function(modalityId) {
		///:id/edit
		//
		console.log('Inside gettemplateInfo:::' + modalityId);
		
		displayVal ='IsEditModality';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		
		
		
		$scope.hostUrl = configUrl.baseurl+"/modalities/" + modalityId + "/edit";
		
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					if(handleResponse(response)) {
						$scope.formData = response.data.data.modality;
						
						console.log('modality info  data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	
	
	//keywords
	
	$scope.addKeyword = function() {
		$scope.formData = {};

		displayVal = 'IsAddKeyword';
		setFlagStatus(displayVal);
		$scope.pagetitle = 'Add Keyword Information';
		
		//$mdSidenav('left').close();
		console.log('add IsAddTemplate::' + $scope.IsAddKeyword);
	};
	
	
$scope.addeditKeywordInfo = function() {
		
		//	  $scope.token = localStorage.getItem('session-token');
		
		//add center information
	console.log('Inside addeditKeywordInfo');
	
	
		var keyword_data = {
			"keywordname" : $scope.formData.keywordname		
			
			};

		if ($scope.IsAddKeyword === true) {
					
			var configData = localStorage.getItem('configData');		
			var configUrl =  JSON.parse(configData);				
			$scope.hostUrl = configUrl.baseurl+configUrl.addKeyword;
			console.log('Url becomes ::' +$scope.hostUrl);
			
			$http({
				method : 'POST',
				url : $scope.hostUrl,
				data : keyword_data,
				headers : {
					'Content-Type' : 'application/json'				
				}

			}).then(function(response) {
				
				if(handleResponse(response)) {				
					openDialog("keyword added successfully");
					$window.location.href = 'index.html';
					console.log('study report added successfully as :' + JSON.stringify(response.data.data.keyword));
				}
			});

		} else if ($scope.IsEditKeyword === true) {
			
			var keywordid = $scope.formData._id;
			console.log('study ID for Edit AS;' + keywordid);
			$scope.hostUrl = "http://localhost:3005/keywords/" + keywordid
					+ "/edit";
			$http({
				method : 'PUT',
				url : $scope.hostUrl,
				data : keyword_data,
				headers : {
					'Content-Type' : 'application/json'
						}

			}).then(
					function(response) {
						console.log("getting keyword_data information as for edit ::"
								+ JSON.stringify(response));						
						if(handleResponse(response)) {
							$scope.formData = response.data.data.keyword;
							openDialog("keyword edited successfully");
							$window.location.href = 'index.html';
							console.log('study added successfully as :' + JSON.stringify(response.data.data.keyword));
						}

					});
		}
	};
	
	$scope.searchKeyword = function() {
		console.log("inside search searchKeyword");
		$scope.keywordResults= [];
		displayVal ='IsSearchKeyword';
		setFlagStatus(displayVal);
		
		
		//$mdSidenav('left').close();		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);				
		$scope.hostUrl = configUrl.baseurl+configUrl.searchKeyword;
	
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'

			}

		}).then(
				function(response) {
					console.log("getting template  information as ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.keywordResults = response.data.data.keywords;
						$scope.IsSearchKeyword = true;
						console.log('getting keywordResults details as :: ' + $scope.keywordResults);
						console.log('value for $scope.keywordResults ' +$scope.IsSearchKeyword );
					
					}

				});

	};
	
	$scope.geteditKeywordInfo = function(keywordId) {
		///:id/edit
		//
		console.log('Inside keywordId:::' + keywordId);
		
		displayVal = 'IsEditKeyword';
		setFlagStatus(displayVal);
		
		//$mdSidenav('left').close();
		
		var configData = localStorage.getItem('configData');		
		var configUrl =  JSON.parse(configData);	
		$scope.hostUrl = configUrl.baseurl+"/keywords/" + keywordId + "/edit";		
		
		$http({
			method : 'GET',
			url : $scope.hostUrl,
			headers : {
				'Content-Type' : 'application/json'
			}

		}).then(
				function(response) {
					console.log("getting keyword information as for edit ::"
							+ JSON.stringify(response));
					if(handleResponse(response)) {
						$scope.formData = response.data.data.keyword;
					
						console.log('keyword info  data as :' + JSON.stringify($scope.formData));
					}

					
				});

	};
	
	//summernote functions

	
	
	
	 $scope.init = function() { console.log('Summernote is launched'); };
     $scope.enter = function() { console.log('Enter/Return key pressed'); };
     $scope.focus = function(e) { console.log('Editable area is focused'); };
     $scope.blur = function(e) { console.log('Editable area loses focus'); };
     $scope.paste = function() { console.log('Called event paste'); };
     $scope.change = function(contents) {
       console.log('contents are changed:', contents, $scope.editable);
     };
     $scope.keyup = function(e) { console.log('Key is released:', e.keyCode); };
     $scope.keydown = function(e) { console.log('Key is pressed:', e.keyCode); };
     $scope.imageUpload = function(files, editor) {
    	 uploadEditorImage(files);
       console.log('image upload:', files, editor);
       console.log('image upload\'s editable:', $scope.editable);
     };
     
 
   
});
